from dataclasses import dataclass
from typing import Optional

@dataclass
class Weakness():
    type: str
    value: str