from dataclasses import dataclass

@dataclass
class SetImage():
    symbol: str
    logo: str