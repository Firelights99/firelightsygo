from dataclasses import dataclass

@dataclass
class AncientTrait():
    name: str
    text: str