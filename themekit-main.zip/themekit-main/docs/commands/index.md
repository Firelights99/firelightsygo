---
title: Command reference
redirect_to: https://shopify.dev/tools/theme-kit/command-reference
---
