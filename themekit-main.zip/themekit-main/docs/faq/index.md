---
title: Troubleshooting
redirect_to: https://shopify.dev/tools/theme-kit/troubleshooting
---
